#include <stdio.h>
#include <stdlib.h>


int troco_possivel(int troco) {
    int notas[] = {2, 5, 10, 20, 50, 100};
    int n = sizeof(notas) / sizeof(notas[0]);
    for (int i = 0; i < n; i++) {
        for (int j = i; j < n; j++) {
            if (notas[i] + notas[j] == troco) {
                return 1; 
            }
        }
    }
    return 0; 
}

int main() {
    char arquivo_entrada[50], arquivo_saida[50];

    printf("Digite o nome do arquivo de entrada: ");
    scanf("%s", arquivo_entrada);
    printf("Digite o nome do arquivo de saída: ");
    scanf("%s", arquivo_saida);

    FILE *entrada = fopen(arquivo_entrada, "r");
    if (entrada == NULL) {
        printf("Erro ao abrir o arquivo de entrada!\n");
        return 1;
    }

    FILE *saida = fopen(arquivo_saida, "w");
    if (saida == NULL) {
        printf("Erro ao abrir o arquivo de saida!\n");
        fclose(entrada);
        return 1;
    }

    int N, M;
    while (fscanf(entrada, "%d %d", &N, &M) == 2) {
        if (N == 0 && M == 0) {
            break;
        }
        int troco = M - N;
        if (troco_possivel(troco)) {
            fprintf(saida, "possible\n");
        } else {
            fprintf(saida, "impossible\n");
        }
    }

    fclose(entrada);
    fclose(saida);
    return 0;
}
